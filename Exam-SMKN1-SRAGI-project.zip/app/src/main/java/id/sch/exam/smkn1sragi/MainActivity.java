package id.sch.exam.smkn1sragi;

import android.app.Activity;
import android.app.AlertDialog;
import android.os.Bundle;
import android.graphics.Color;
import android.graphics.Typeface;
import android.view.Gravity;
import android.view.View;
import android.widget.*;
import org.json.JSONArray;
import org.json.JSONObject;
import java.util.ArrayList;

public class MainActivity extends Activity {
    private LinearLayout root;
    private final ArrayList<Question> questions = new ArrayList<>();
    private int questionIndex = 0, score = 0;
    private String studentName = "Siswa";
    private RadioGroup choices;
    private int selected = -1;

    static class Question {
        String text;
        String[] options;
        int answer;
        Question(String t, String a, String b, String c, String d, int correct) {
            text=t; options=new String[]{a,b,c,d}; answer=correct;
        }
        JSONObject json() throws Exception {
            JSONObject o=new JSONObject(); o.put("text",text);
            JSONArray a=new JSONArray(); for(String s:options)a.put(s);
            o.put("options",a); o.put("answer",answer); return o;
        }
    }

    @Override public void onCreate(Bundle saved) {
        super.onCreate(saved);
        getWindow().setStatusBarColor(Color.rgb(18,52,91));
        getWindow().setNavigationBarColor(Color.BLACK);
        loadQuestions();
        showLogin();
    }

    private void setup(String title) {
        root = new LinearLayout(this); root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(24,24,24,24); root.setBackgroundColor(Color.rgb(245,248,252));
        ScrollView sc = new ScrollView(this); sc.addView(root);
        setContentView(sc);
        TextView heading = new TextView(this); heading.setText(title);
        heading.setTextSize(24); heading.setTypeface(null, Typeface.BOLD);
        heading.setTextColor(Color.rgb(18,52,91)); heading.setPadding(0,8,0,20);
        root.addView(heading);
    }
    private TextView text(String s, int size) {
        TextView v=new TextView(this); v.setText(s); v.setTextSize(size);
        v.setTextColor(Color.rgb(35,45,60)); v.setPadding(0,8,0,12); return v;
    }
    private EditText field(String hint) {
        EditText e=new EditText(this); e.setSingleLine(true); e.setHint(hint);
        e.setTextSize(16); root.addView(e, new LinearLayout.LayoutParams(-1,-2)); return e;
    }
    private Button button(String label, Runnable action) {
        Button b=new Button(this); b.setText(label); b.setAllCaps(false);
        root.addView(b,new LinearLayout.LayoutParams(-1,-2));
        b.setOnClickListener(v->action.run()); return b;
    }
    private void showLogin() {
        setup("Exam SMKN 1 Sragi");
        root.addView(text("Aplikasi ujian sekolah\nSilakan masuk menggunakan akun demo.",16));
        EditText user=field("Username");
        EditText pass=field("Password"); pass.setInputType(129);
        button("Login",()->{
            String u=user.getText().toString().trim(), p=pass.getText().toString();
            if(u.equals("admin") && p.equals("admin123")) showAdmin();
            else if(!u.isEmpty() && p.equals("siswa123")) {
                studentName=u; questionIndex=0; score=0; showQuestion();
            } else new AlertDialog.Builder(this).setTitle("Login gagal")
                .setMessage("Akun demo:\nAdmin: admin / admin123\nSiswa: nama pengguna apa saja / siswa123")
                .setPositiveButton("OK",null).show();
        });
        root.addView(text("Akun demo:\nAdmin: admin / admin123\nSiswa: username bebas / siswa123",14));
    }
    private void showQuestion() {
        if(questionIndex>=questions.size()){showResult();return;}
        Question q=questions.get(questionIndex); selected=-1;
        setup("Ujian — "+studentName);
        root.addView(text("Soal "+(questionIndex+1)+" dari "+questions.size(),15));
        root.addView(text(q.text,19));
        choices=new RadioGroup(this); choices.setOrientation(RadioGroup.VERTICAL);
        for(int i=0;i<q.options.length;i++){
            RadioButton rb=new RadioButton(this); rb.setText(q.options[i]); rb.setTextSize(16); rb.setId(100+i);
            choices.addView(rb); }
        root.addView(choices);
        button(questionIndex==questions.size()-1?"Selesai":"Soal berikutnya",()->{
            int id=choices.getCheckedRadioButtonId();
            if(id==-1){Toast.makeText(this,"Pilih salah satu jawaban.",Toast.LENGTH_SHORT).show();return;}
            if(id-100==q.answer)score++;
            questionIndex++;showQuestion();
        });
        button("Keluar",this::showLogin);
    }
    private void showResult() {
        setup("Hasil Ujian");
        int percent=questions.isEmpty()?0:(score*100/questions.size());
        root.addView(text("Nama: "+studentName,18));
        root.addView(text("Jawaban benar: "+score+" dari "+questions.size(),20));
        root.addView(text("Nilai: "+percent,30));
        button("Kembali ke Login",this::showLogin);
    }
    private void showAdmin() {
        setup("Panel Admin");
        root.addView(text("Kelola soal ujian di perangkat ini.",16));
        for(int i=0;i<questions.size();i++){
            final int ix=i;
            root.addView(text((i+1)+". "+questions.get(i).text,16));
            button("Hapus soal "+(i+1),()->{
                questions.remove(ix);saveQuestions();showAdmin();
            });
        }
        button("Tambah soal",this::addQuestion);
        button("Reset soal contoh",()->{
            seedQuestions();saveQuestions();showAdmin();
        });
        button("Logout",this::showLogin);
    }
    private void addQuestion() {
        LinearLayout form=new LinearLayout(this);form.setPadding(16,8,16,8);form.setOrientation(LinearLayout.VERTICAL);
        EditText q=new EditText(this);q.setHint("Teks pertanyaan");form.addView(q);
        EditText[] opts=new EditText[4];
        for(int i=0;i<4;i++){opts[i]=new EditText(this);opts[i].setHint("Pilihan "+(char)('A'+i));form.addView(opts[i]);}
        EditText ans=new EditText(this);ans.setHint("Jawaban benar: A, B, C, atau D");form.addView(ans);
        new AlertDialog.Builder(this).setTitle("Tambah soal").setView(form)
            .setNegativeButton("Batal",null).setPositiveButton("Simpan",(d,w)->{
                String t=q.getText().toString().trim(), a=ans.getText().toString().trim().toUpperCase();
                if(t.isEmpty()||a.length()!=1||"ABCD".indexOf(a)<0){
                    Toast.makeText(this,"Isi pertanyaan dan jawaban A/B/C/D dengan benar.",Toast.LENGTH_LONG).show();return;}
                String[] op=new String[4];for(int i=0;i<4;i++)op[i]=opts[i].getText().toString().trim();
                for(String s:op)if(s.isEmpty()){Toast.makeText(this,"Semua pilihan jawaban harus diisi.",Toast.LENGTH_LONG).show();return;}
                questions.add(new Question(t,op[0],op[1],op[2],op[3],a.charAt(0)-'A'));
                saveQuestions();showAdmin();
            }).show();
    }
    private void seedQuestions() {
        questions.clear();
        questions.add(new Question("Apa kepanjangan DKV?","Desain Komunikasi Visual","Dasar Komputer Visual","Desain Kreatif Video","Dokumen Komunikasi Visual",0));
        questions.add(new Question("Warna primer dalam model warna tradisional adalah...","Hijau, jingga, ungu","Merah, kuning, biru","Hitam, putih, abu-abu","Merah muda, cokelat, emas",1));
        questions.add(new Question("Aplikasi yang digunakan untuk membuat dokumen teks adalah...","Microsoft Word","Kalkulator","Pemutar musik","Galeri",0));
    }
    private void loadQuestions() {
        String raw=getPreferences(0).getString("questions",null);
        if(raw==null){seedQuestions();return;}
        try{
            JSONArray a=new JSONArray(raw);
            for(int i=0;i<a.length();i++){
                JSONObject o=a.getJSONObject(i);JSONArray op=o.getJSONArray("options");
                questions.add(new Question(o.getString("text"),op.getString(0),op.getString(1),op.getString(2),op.getString(3),o.getInt("answer")));
            }
            if(questions.isEmpty())seedQuestions();
        }catch(Exception e){seedQuestions();}
    }
    private void saveQuestions() {
        try{
            JSONArray a=new JSONArray();for(Question q:questions)a.put(q.json());
            getPreferences(0).edit().putString("questions",a.toString()).apply();
        }catch(Exception ignored){}
    }
}
